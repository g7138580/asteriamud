#ifndef DESTINY_H
#define DESTINY_H

#include "Entities/Unit.h"

extern void AddDestiny( UNIT *unit, int value );

#endif
